var searchData=
[
  ['nombre_0',['nombre',['../struct_cjt__jugadores_1_1_jugador__ran.html#af805bb02fd50dd5a5f005ab425410f88',1,'Cjt_jugadores::Jugador_ran::nombre()'],['../class_jugador.html#ae173555c513c4267f92c915e94c7e524',1,'Jugador::nombre()'],['../struct_torneo_1_1jugador__torneo.html#a2c9172ebf2a3d1954edb3d18b85c40d7',1,'Torneo::jugador_torneo::nombre()']]],
  ['nombre_5fcategoria_1',['nombre_categoria',['../class_torneo.html#a3187045957c075f255c94bd4dba1820b',1,'Torneo']]],
  ['nombre_5ftorneo_2',['nombre_torneo',['../class_torneo.html#ab975e6b38e92fee0bc0842656f86c974',1,'Torneo']]],
  ['num_5fc_3',['num_C',['../class_categorias.html#a4f93908d53209fd4a83d04a5a9962183',1,'Categorias']]],
  ['num_5fk_4',['num_K',['../class_categorias.html#a49dc2a97575119f89f4f79502c657dfe',1,'Categorias']]]
];
