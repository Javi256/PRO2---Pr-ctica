var searchData=
[
  ['jugador_0',['Jugador',['../class_jugador.html#a232c46f75691af6210096e5972535d71',1,'Jugador::Jugador()'],['../class_jugador.html#a7387e8d28f73f109587ae05cb3aec86e',1,'Jugador::Jugador(string &amp;p)']]]
];
