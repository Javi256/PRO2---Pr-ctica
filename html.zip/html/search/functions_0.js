var searchData=
[
  ['actualizar_5festadisticas_0',['actualizar_estadisticas',['../class_jugador.html#a5333bc5bf20050d3a7328643bec178f1',1,'Jugador']]],
  ['actualizar_5festadisticas_5fjugadores_1',['actualizar_estadisticas_jugadores',['../class_torneo.html#a51c1256b1c9d57406ab01bdcdc514dac',1,'Torneo']]],
  ['actualizar_5franking_2',['actualizar_ranking',['../class_cjt__jugadores.html#ac7930b74caf759755a254e0badafc0d3',1,'Cjt_jugadores']]],
  ['anadir_5fnom_5fcat_3',['anadir_nom_cat',['../class_cjt__torneos.html#a0254df86a4a9d380a20758233ba8df7a',1,'Cjt_torneos']]],
  ['analizar_5fpartido_4',['analizar_partido',['../class_torneo.html#a8861779aab2fa871f94b5c084986387c',1,'Torneo']]],
  ['analizar_5ftorneo_5',['analizar_torneo',['../class_torneo.html#a81ef562db8f2c5a5e89330fa9e401040',1,'Torneo']]]
];
