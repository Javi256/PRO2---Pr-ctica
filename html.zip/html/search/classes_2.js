var searchData=
[
  ['jugador_0',['Jugador',['../class_jugador.html',1,'']]],
  ['jugador_5fran_1',['Jugador_ran',['../struct_cjt__jugadores_1_1_jugador__ran.html',1,'Cjt_jugadores']]],
  ['jugador_5ftorneo_2',['jugador_torneo',['../struct_torneo_1_1jugador__torneo.html',1,'Torneo']]]
];
