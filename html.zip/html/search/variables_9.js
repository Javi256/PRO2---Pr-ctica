var searchData=
[
  ['ts_0',['Ts',['../class_jugador.html#a75f287e5295b42e81cc80d88bba15e64',1,'Jugador']]]
];
