var searchData=
[
  ['p_0',['p',['../class_bin_tree.html#afe3647af1dda90f6ddf1deee6560fcf1',1,'BinTree']]],
  ['partidos_5fganados_1',['partidos_ganados',['../struct_torneo_1_1jugador__torneo.html#aac75f25e6675ec005f1b9af59351bff8',1,'Torneo::jugador_torneo']]],
  ['partidos_5fperdidos_2',['partidos_perdidos',['../struct_torneo_1_1jugador__torneo.html#aebc52da3b9a90ffc26ab546207b54e76',1,'Torneo::jugador_torneo']]],
  ['pos_5fant_3',['pos_ant',['../struct_cjt__jugadores_1_1_jugador__ran.html#ab73a69757fb8db696ca6f263005d3185',1,'Cjt_jugadores::Jugador_ran']]],
  ['puntos_4',['puntos',['../struct_cjt__jugadores_1_1_jugador__ran.html#ab7429a798f813c92db8f7cfd8117a737',1,'Cjt_jugadores::Jugador_ran::puntos()'],['../class_jugador.html#a4e264d857d5a3f1a68cbb13e4b88930f',1,'Jugador::puntos()'],['../struct_torneo_1_1jugador__torneo.html#ac6eb4376c9dc06b6fb782247d2192f1d',1,'Torneo::jugador_torneo::puntos()']]],
  ['puntos_5',['Puntos',['../class_categorias.html#a0373802480422fb3050ea4322d524f15',1,'Categorias']]],
  ['puntos_5fanteriores_6',['puntos_anteriores',['../class_torneo.html#aedf824be502b22e0aac8ab2b1b7422af',1,'Torneo']]]
];
