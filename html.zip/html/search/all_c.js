var searchData=
[
  ['sets_5fganados_0',['sets_ganados',['../struct_torneo_1_1jugador__torneo.html#a85bef2962e440ca76d5c09456ccb6c29',1,'Torneo::jugador_torneo']]],
  ['sets_5fperdidos_1',['sets_perdidos',['../struct_torneo_1_1jugador__torneo.html#a7dbe6fb050c2af77c713ba6cc994babb',1,'Torneo::jugador_torneo']]]
];
