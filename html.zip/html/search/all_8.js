var searchData=
[
  ['main_0',['main',['../program_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'program.cc']]],
  ['modificar_5fjugador_1',['modificar_jugador',['../class_cjt__jugadores.html#a43443ac0db286f438a6b2c3380de7f56',1,'Cjt_jugadores']]],
  ['modificar_5fnom_5fcat_2',['modificar_nom_cat',['../class_torneo.html#afdb0e2b1a1e23102fd48bf3314b3b5e1',1,'Torneo']]],
  ['modificar_5fpuntos_3',['modificar_puntos',['../class_jugador.html#a526256dbefbcbd40af352e40f11d37e5',1,'Jugador']]],
  ['modificar_5franking_4',['modificar_ranking',['../class_jugador.html#a4cf9a015f64d2fff32e0c956c99f4427',1,'Jugador']]],
  ['modificar_5ftorneo_5',['modificar_torneo',['../class_cjt__torneos.html#a2360427a889e5db8cb0af9e197328504',1,'Cjt_torneos']]]
];
