var searchData=
[
  ['restar_5fpuntos_0',['restar_puntos',['../class_torneo.html#a7b8aa2bc5c3ea3a7c176f7d045599847',1,'Torneo']]],
  ['right_1',['right',['../class_bin_tree.html#aff8e96651b27284c329667b5ad3e4d0b',1,'BinTree']]]
];
