var searchData=
[
  ['emp_0',['emp',['../class_torneo.html#a7ced527ef54783c0d0e7a557144632d0',1,'Torneo']]]
];
