var searchData=
[
  ['aparecido_0',['aparecido',['../struct_torneo_1_1jugador__torneo.html#a9338ea04abe4fa684073e88bc9878d09',1,'Torneo::jugador_torneo']]]
];
