var searchData=
[
  ['juegos_5fganados_0',['juegos_ganados',['../struct_torneo_1_1jugador__torneo.html#a4e9fc66c09e1f61bd535ba07151f63c8',1,'Torneo::jugador_torneo']]],
  ['juegos_5fperdidos_1',['juegos_perdidos',['../struct_torneo_1_1jugador__torneo.html#aedae25d7e57d9e4ff290b0b9b7a65837',1,'Torneo::jugador_torneo']]],
  ['jugadores_5ftorneo_2',['jugadores_torneo',['../class_torneo.html#ace57ca7f2bd0dfd8dfd0c9dcb49fa5aa',1,'Torneo']]]
];
