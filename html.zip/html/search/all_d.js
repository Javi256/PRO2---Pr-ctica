var searchData=
[
  ['torneo_0',['Torneo',['../class_torneo.html',1,'Torneo'],['../class_torneo.html#a7bf6d35a7ec8d0e13a0bed8deb8add3e',1,'Torneo::Torneo()'],['../class_torneo.html#ae555c19eac665fda0e81ed5e7fe55c6d',1,'Torneo::Torneo(string &amp;t, int &amp;c)']]],
  ['torneo_2ecc_1',['Torneo.cc',['../_torneo_8cc.html',1,'']]],
  ['torneo_2ehh_2',['Torneo.hh',['../_torneo_8hh.html',1,'']]],
  ['ts_3',['Ts',['../class_jugador.html#a75f287e5295b42e81cc80d88bba15e64',1,'Jugador']]]
];
