var searchData=
[
  ['finalizar_5ftorneo_0',['finalizar_torneo',['../class_torneo.html#a8c9573d168ed9e7e5034d53e1cac223f',1,'Torneo']]]
];
