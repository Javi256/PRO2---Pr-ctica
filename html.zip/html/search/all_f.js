var searchData=
[
  ['wg_0',['WG',['../class_jugador.html#ac9178c08efb18c27796e68ac47b0ae9f',1,'Jugador']]],
  ['wm_1',['WM',['../class_jugador.html#a1f13d28460688bb3c5baef0f51c42d1c',1,'Jugador']]],
  ['ws_2',['WS',['../class_jugador.html#a5cd43b7087aa8f560e63a47b0f97dc3d',1,'Jugador']]]
];
