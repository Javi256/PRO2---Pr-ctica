var searchData=
[
  ['juegos_5fganados_0',['juegos_ganados',['../struct_torneo_1_1jugador__torneo.html#a4e9fc66c09e1f61bd535ba07151f63c8',1,'Torneo::jugador_torneo']]],
  ['juegos_5fperdidos_1',['juegos_perdidos',['../struct_torneo_1_1jugador__torneo.html#aedae25d7e57d9e4ff290b0b9b7a65837',1,'Torneo::jugador_torneo']]],
  ['jugador_2',['Jugador',['../class_jugador.html',1,'Jugador'],['../class_jugador.html#a232c46f75691af6210096e5972535d71',1,'Jugador::Jugador()'],['../class_jugador.html#a7387e8d28f73f109587ae05cb3aec86e',1,'Jugador::Jugador(string &amp;p)']]],
  ['jugador_2ecc_3',['Jugador.cc',['../_jugador_8cc.html',1,'']]],
  ['jugador_2ehh_4',['Jugador.hh',['../_jugador_8hh.html',1,'']]],
  ['jugador_5fran_5',['Jugador_ran',['../struct_cjt__jugadores_1_1_jugador__ran.html',1,'Cjt_jugadores']]],
  ['jugador_5ftorneo_6',['jugador_torneo',['../struct_torneo_1_1jugador__torneo.html',1,'Torneo']]],
  ['jugadores_5ftorneo_7',['jugadores_torneo',['../class_torneo.html#ace57ca7f2bd0dfd8dfd0c9dcb49fa5aa',1,'Torneo']]]
];
