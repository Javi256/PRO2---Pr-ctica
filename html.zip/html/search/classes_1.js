var searchData=
[
  ['categorias_0',['Categorias',['../class_categorias.html',1,'']]],
  ['cjt_5fjugadores_1',['Cjt_jugadores',['../class_cjt__jugadores.html',1,'']]],
  ['cjt_5ftorneos_2',['Cjt_torneos',['../class_cjt__torneos.html',1,'']]]
];
