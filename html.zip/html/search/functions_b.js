var searchData=
[
  ['torneo_0',['Torneo',['../class_torneo.html#a7bf6d35a7ec8d0e13a0bed8deb8add3e',1,'Torneo::Torneo()'],['../class_torneo.html#ae555c19eac665fda0e81ed5e7fe55c6d',1,'Torneo::Torneo(string &amp;t, int &amp;c)']]]
];
