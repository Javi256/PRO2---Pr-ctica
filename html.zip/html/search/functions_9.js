var searchData=
[
  ['node_0',['Node',['../struct_bin_tree_1_1_node.html#af45885e303875c018e89fa5c8b96bde0',1,'BinTree::Node']]],
  ['nuevo_5fjugador_1',['nuevo_jugador',['../class_cjt__jugadores.html#a07b5c2d798c81dab2d50d92145d1e931',1,'Cjt_jugadores']]],
  ['nuevo_5ftorneo_2',['nuevo_torneo',['../class_cjt__torneos.html#a200ff2c02b9b2adb6163a6544cbe7c60',1,'Cjt_torneos']]],
  ['numero_5fjugadores_3',['numero_jugadores',['../class_cjt__jugadores.html#a1fe98992697035cf4002f0788d783d25',1,'Cjt_jugadores']]],
  ['numero_5ftorneos_4',['numero_torneos',['../class_cjt__torneos.html#a7d0e2c45a4956e5a2282e2dde7ec917c',1,'Cjt_torneos']]]
];
