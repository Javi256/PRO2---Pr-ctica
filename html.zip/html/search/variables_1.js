var searchData=
[
  ['categoria_0',['categoria',['../class_torneo.html#ad9bec7ef311a416138abb99f3a487b3e',1,'Torneo']]],
  ['cjt_5fcategorias_1',['Cjt_categorias',['../class_categorias.html#acaa7aed2307d1f108e7ca114ba5e7938',1,'Categorias']]],
  ['cjt_5fjugadores_2',['cjt_jugadores',['../class_cjt__jugadores.html#afe737593f9db0684a9b304bbfdd4a57b',1,'Cjt_jugadores']]],
  ['cjt_5ftorneos_3',['cjt_torneos',['../class_cjt__torneos.html#ac409fd1725d4624c10bdba84ffe87a3e',1,'Cjt_torneos']]]
];
