var searchData=
[
  ['node_0',['Node',['../struct_bin_tree_1_1_node.html',1,'BinTree&lt; T &gt;::Node'],['../struct_bin_tree_1_1_node.html#af45885e303875c018e89fa5c8b96bde0',1,'BinTree::Node::Node()']]],
  ['nombre_1',['nombre',['../struct_cjt__jugadores_1_1_jugador__ran.html#af805bb02fd50dd5a5f005ab425410f88',1,'Cjt_jugadores::Jugador_ran::nombre()'],['../class_jugador.html#ae173555c513c4267f92c915e94c7e524',1,'Jugador::nombre()'],['../struct_torneo_1_1jugador__torneo.html#a2c9172ebf2a3d1954edb3d18b85c40d7',1,'Torneo::jugador_torneo::nombre()']]],
  ['nombre_5fcategoria_2',['nombre_categoria',['../class_torneo.html#a3187045957c075f255c94bd4dba1820b',1,'Torneo']]],
  ['nombre_5ftorneo_3',['nombre_torneo',['../class_torneo.html#ab975e6b38e92fee0bc0842656f86c974',1,'Torneo']]],
  ['nuevo_5fjugador_4',['nuevo_jugador',['../class_cjt__jugadores.html#a07b5c2d798c81dab2d50d92145d1e931',1,'Cjt_jugadores']]],
  ['nuevo_5ftorneo_5',['nuevo_torneo',['../class_cjt__torneos.html#a200ff2c02b9b2adb6163a6544cbe7c60',1,'Cjt_torneos']]],
  ['num_5fc_6',['num_C',['../class_categorias.html#a4f93908d53209fd4a83d04a5a9962183',1,'Categorias']]],
  ['num_5fk_7',['num_K',['../class_categorias.html#a49dc2a97575119f89f4f79502c657dfe',1,'Categorias']]],
  ['numero_5fjugadores_8',['numero_jugadores',['../class_cjt__jugadores.html#a1fe98992697035cf4002f0788d783d25',1,'Cjt_jugadores']]],
  ['numero_5ftorneos_9',['numero_torneos',['../class_cjt__torneos.html#a7d0e2c45a4956e5a2282e2dde7ec917c',1,'Cjt_torneos']]]
];
